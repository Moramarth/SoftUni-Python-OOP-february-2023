from project.room import Room


class Hotel:
    def __init__(self, name: str):
        self.name = name
        self.rooms = list()  # stores instances of Room class
        self.guests = 0

    @classmethod
    def from_stars(cls, stars_count: int):
        return cls(f"{stars_count} stars Hotel")

    def add_room(self, room: Room):
        self.rooms.append(room)

    def take_room(self, room_number, people):
        searched_room = next(filter(lambda r: r.number == room_number, self.rooms))
        result = searched_room.take_room(people)
        if not result:
            self.guests += people

    def free_room(self, room_number):
        searched_room = next(filter(lambda r: r.number == room_number, self.rooms))
        guests_in_room = searched_room.guests
        result = searched_room.free_room()
        if not result:
            self.guests -= guests_in_room

    def status(self):
        return f"Hotel {self.name} has {self.guests} total guests\n" \
                f"Free rooms: {', '.join((str(room.number) for room in self.rooms if not room.is_taken))}\n" \
                f"Taken rooms: {', '.join((str(room.number) for room in self.rooms if  room.is_taken))}"
