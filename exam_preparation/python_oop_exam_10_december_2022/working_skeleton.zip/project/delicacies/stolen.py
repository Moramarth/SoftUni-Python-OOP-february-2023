from project.delicacies.delicacy import Delicacy


class Stolen(Delicacy):
    def __init__(self, name: str, price: float):
        super().__init__(name, self.portion_size(), price)

    def portion_size(self):
        return 250

    def delicacy_type(self):
        return Stolen
