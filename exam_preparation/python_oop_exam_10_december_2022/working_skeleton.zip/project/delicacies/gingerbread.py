from project.delicacies.delicacy import Delicacy


class Gingerbread(Delicacy):
    def __init__(self, name: str, price: float):
        super().__init__(name, self.portion_size(), price)

    def portion_size(self):
        return 200

    def delicacy_type(self):
        return Gingerbread
