from project.astronaut.astronaut import Astronaut


class PlanetRepository:
    def __init__(self):
        self.planets = list()

    def add(self, astronaut: Astronaut):
        self.planets.append(astronaut)

    def remove(self, astronaut: Astronaut):
        self.planets.remove(astronaut)

    def find_by_name(self, name: str):
        for planet in self.planets:
            if planet.name == name:
                return planet
