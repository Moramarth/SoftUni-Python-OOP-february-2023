from project.astronaut.astronaut import Astronaut


class Geodesist(Astronaut):
    _DEFAULT_OXYGEN_START = 50

    def __init__(self, name: str):
        super().__init__(name, self._DEFAULT_OXYGEN_START)

    @property
    def take_a_breath(self):
        return 10
