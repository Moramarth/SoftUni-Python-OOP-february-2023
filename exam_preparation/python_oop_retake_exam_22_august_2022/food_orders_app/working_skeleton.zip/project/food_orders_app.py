from project.meals.meal import Meal


class FoodOrdersApp:
    def __init__(self):
        self.menu = list()  # stores objects of type Meal
        self.clients_list = list()  # stores objects of type Client

    def register_client(self, client_phone_number: str):
        pass

    def add_meals_to_menu(self, *meals: Meal):
        pass

    def show_menu(self):
        pass

    def add_meals_to_shopping_cart(self, client_phone_number: str, **meal_names_and_quantities):
        pass

    def cancel_order(self, client_phone_number: str):
        pass

    def finish_order(self, client_phone_number: str):
        pass

    def __str__(self):
        return f"Food Orders App has {len(self.menu)} meals on the menu and {len(self.clients_list)} clients."