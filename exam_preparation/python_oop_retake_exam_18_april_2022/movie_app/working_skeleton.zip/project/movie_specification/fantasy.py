from project.movie_specification.movie import Movie


class Fantasy(Movie):
    def __init__(self, title: str, year: int, owner: object, age_restriction=None):
        if self.age_restriction is None:
            age_restriction = self.age_restriction_by_genre
        super().__init__(title, year, owner, age_restriction)

    @property
    def age_restriction_by_genre(self):
        return 6
