from project.hardware.hardware import Hardware


class PowerHardware(Hardware):
    __CAPACITY_DECREASE = 0.25
    __MEMORY_INCREASE = 0.75

    def __init__(self, name: str, capacity: int, memory: int):
        super().__init__(name, self.default_type, capacity, memory)
        self.capacity = int(self.capacity * self.__CAPACITY_DECREASE)
        self.memory += int(self.memory * self.__MEMORY_INCREASE)

    @property
    def default_type(self):
        return "Power"
