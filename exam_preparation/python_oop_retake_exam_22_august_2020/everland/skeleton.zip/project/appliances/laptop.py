from project.appliances.appliance import Appliance


class Laptop(Appliance):
    def __init__(self):
        super().__init__(self.default_cost_for_type)

    @property
    def default_cost_for_type(self):
        return 1
